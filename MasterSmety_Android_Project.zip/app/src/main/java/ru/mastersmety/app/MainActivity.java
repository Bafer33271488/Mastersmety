package ru.mastersmety.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int CREATE_PDF = 71;
    private android.content.SharedPreferences prefs;
    private JSONObject data;
    private int currentProject = -1;
    private int currentRoom = -1;
    private byte[] pendingPdf;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("master_smety", MODE_PRIVATE);
        loadData();
        showHome();
    }

    private JSONObject obj() { return new JSONObject(); }
    private JSONArray arr() { return new JSONArray(); }
    private void loadData() {
        try {
            String raw = prefs.getString("data", null);
            if (raw != null) data = new JSONObject(raw);
            else {
                data = obj();
                data.put("fio", "");
                data.put("phone", "");
                JSONArray prices = arr();
                prices.put(price(1,"Шпаклёвка стен","м²",500));
                prices.put(price(2,"Декоративная штукатурка","м²",700));
                prices.put(price(3,"Заделка штроб","пог. м",200));
                prices.put(price(4,"Монтаж уголков","пог. м",150));
                prices.put(price(5,"Грунтовка","м²",100));
                prices.put(price(6,"Покраска","м²",350));
                data.put("prices", prices);
                data.put("projects", arr());
                saveData();
            }
        } catch(Exception e) { data = obj(); try { data.put("prices",arr()); data.put("projects",arr()); } catch(Exception ignored) {} }
    }
    private JSONObject price(int id, String name, String unit, double value) throws Exception {
        JSONObject p = obj(); p.put("id",id); p.put("name",name); p.put("unit",unit); p.put("price",value); return p;
    }
    private void saveData() { prefs.edit().putString("data", data.toString()).apply(); }
    private JSONArray getArray(JSONObject o, String k) { JSONArray a=o.optJSONArray(k); return a==null?arr():a; }
    private JSONObject findById(JSONArray a, int id) {
        for(int i=0;i<a.length();i++){ JSONObject x=a.optJSONObject(i); if(x!=null&&x.optInt("id")==id)return x; } return null;
    }
    private int nextId(JSONArray a) { int m=0; for(int i=0;i<a.length();i++)m=Math.max(m,a.optJSONObject(i).optInt("id")); return m+1; }
    private double num(String s) { try{return Math.max(0,Double.parseDouble(s.trim().replace(',','.')));}catch(Exception e){return 0;} }
    private String fmt(double n) { return String.format(Locale.forLanguageTag("ru-RU"),"%.2f",n).replaceAll(",00$",""); }
    private String rub(double n) { return String.format(Locale.forLanguageTag("ru-RU"),"%,.0f ₽",n).replace(',',' '); }

    private LinearLayout root(String title) {
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(20,18,20,20); page.setBackgroundColor(0xFFFFFFFF);
        TextView h = new TextView(this); h.setText(title); h.setTextSize(24); h.setTypeface(null,Typeface.BOLD);
        h.setTextColor(0xFF202020); h.setPadding(0,0,0,14); page.addView(h);
        ScrollView scroll = new ScrollView(this); LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(body); page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(page); return body;
    }
    private TextView text(String s, int size) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(0xFF202020); t.setPadding(0,8,0,8); return t; }
    private Button button(String s, LinearLayout into, View.OnClickListener click) {
        Button b=new Button(this); b.setText(s); into.addView(b,new LinearLayout.LayoutParams(-1,-2)); b.setOnClickListener(click); return b;
    }
    private EditText edit(String hint, String value, int type) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setText(value==null?"":value); e.setInputType(type);
        return e;
    }
    private void showHome() {
        LinearLayout b=root("Мастер Сметы");
        b.addView(text("Сметы на отделочные работы",16));
        button("Проекты",b,v->showProjects());
        button("Прайс-лист",b,v->showPrices());
        button("Мои данные",b,v->showProfile());
        button("Сформировать PDF проекта",b,v->{
            JSONArray ps=getArray(data,"projects");
            if(ps.length()==0){toast("Сначала создай проект");return;}
            chooseProjectForPdf();
        });
        b.addView(text("Тестовая версия. Данные хранятся на этом телефоне.",13));
    }
    private void showProfile() {
        LinearLayout b=root("Мои данные");
        EditText fio=edit("ФИО исполнителя",data.optString("fio",""),InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText phone=edit("Номер телефона",data.optString("phone",""),InputType.TYPE_CLASS_PHONE);
        b.addView(text("ФИО",14)); b.addView(fio); b.addView(text("Номер телефона",14)); b.addView(phone);
        button("Сохранить данные",b,v->{try{data.put("fio",fio.getText().toString().trim());data.put("phone",phone.getText().toString().trim());saveData();toast("Данные сохранены");showHome();}catch(Exception ignored){}});
        button("Назад",b,v->showHome());
    }
    private void showPrices() {
        LinearLayout b=root("Прайс-лист");
        JSONArray ps=getArray(data,"prices");
        for(int i=0;i<ps.length();i++){
            JSONObject p=ps.optJSONObject(i); if(p==null)continue; final int id=p.optInt("id");
            b.addView(text(p.optString("name")+" — "+fmt(p.optDouble("price"))+" ₽/"+p.optString("unit"),16));
            button("Изменить",b,v->editPrice(id));
            button("Удалить",b,v->{removeById(getArray(data,"prices"),id);saveData();showPrices();});
        }
        button("Добавить вид работ",b,v->addPriceDialog());
        button("Назад",b,v->showHome());
    }
    private void editPrice(int id) {
        JSONObject p=findById(getArray(data,"prices"),id); if(p==null)return;
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,4,24,4);
        EditText n=edit("Название",p.optString("name"),InputType.TYPE_CLASS_TEXT); EditText pr=edit("Цена",fmt(p.optDouble("price")),InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        Spinner sp=unitSpinner(p.optString("unit")); l.addView(n);l.addView(sp);l.addView(pr);
        new AlertDialog.Builder(this).setTitle("Изменить расценку").setView(l).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{try{p.put("name",n.getText().toString().trim());p.put("unit",sp.getSelectedItem().toString());p.put("price",num(pr.getText().toString()));saveData();showPrices();}catch(Exception ignored){}}).show();
    }
    private void addPriceDialog() {
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,4,24,4);
        EditText n=edit("Название работы","",InputType.TYPE_CLASS_TEXT); Spinner sp=unitSpinner("м²"); EditText pr=edit("Цена за единицу","0",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        l.addView(n);l.addView(sp);l.addView(pr);
        new AlertDialog.Builder(this).setTitle("Новая работа").setView(l).setNegativeButton("Отмена",null).setPositiveButton("Добавить",(d,w)->{try{JSONArray a=getArray(data,"prices");JSONObject p=price(nextId(a),n.getText().toString().trim(),sp.getSelectedItem().toString(),num(pr.getText().toString()));a.put(p);data.put("prices",a);saveData();showPrices();}catch(Exception ignored){}}).show();
    }
    private Spinner unitSpinner(String selected) {
        Spinner s=new Spinner(this);String[] units={"м²","пог. м","шт."};s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,units));
        for(int i=0;i<units.length;i++)if(units[i].equals(selected))s.setSelection(i);return s;
    }
    private void showProjects() {
        LinearLayout b=root("Проекты"); JSONArray ps=getArray(data,"projects");
        for(int i=0;i<ps.length();i++){JSONObject p=ps.optJSONObject(i);if(p==null)continue;final int id=p.optInt("id");
            button(p.optString("name")+" — "+rub(projectTotal(p)),b,v->{currentProject=id;showProject();});
        }
        button("+ Создать проект",b,v->newProjectDialog());
        button("Назад",b,v->showHome());
    }
    private void newProjectDialog() {
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,4,24,4);
        EditText n=edit("Название проекта","",InputType.TYPE_CLASS_TEXT);EditText a=edit("Адрес объекта","",InputType.TYPE_CLASS_TEXT);
        l.addView(n);l.addView(a);
        new AlertDialog.Builder(this).setTitle("Новый проект").setView(l).setNegativeButton("Отмена",null).setPositiveButton("Создать",(d,w)->{try{JSONArray ps=getArray(data,"projects");JSONObject p=obj();p.put("id",nextId(ps));p.put("name",n.getText().toString().trim());p.put("address",a.getText().toString().trim());p.put("rooms",arr());ps.put(p);data.put("projects",ps);saveData();currentProject=p.optInt("id");showProject();}catch(Exception ignored){}}).show();
    }
    private JSONObject project() {return findById(getArray(data,"projects"),currentProject);}
    private void showProject() {
        JSONObject p=project(); if(p==null){showProjects();return;}
        LinearLayout b=root(p.optString("name","Проект"));
        EditText name=edit("Название проекта",p.optString("name"),InputType.TYPE_CLASS_TEXT);EditText addr=edit("Адрес",p.optString("address"),InputType.TYPE_CLASS_TEXT);
        b.addView(text("Название проекта",14));b.addView(name);b.addView(text("Адрес объекта",14));b.addView(addr);
        button("Сохранить название и адрес",b,v->{try{p.put("name",name.getText().toString());p.put("address",addr.getText().toString());saveData();toast("Сохранено");showProject();}catch(Exception ignored){}});
        JSONArray rs=getArray(p,"rooms");
        b.addView(text("Комнаты",18));
        for(int i=0;i<rs.length();i++){JSONObject r=rs.optJSONObject(i);if(r==null)continue;final int id=r.optInt("id");
            button(r.optString("name")+" · "+fmt(roomArea(r))+" м² · "+rub(roomTotal(r)),b,v->{currentRoom=id;showRoom();});
        }
        button("+ Добавить комнату",b,v->newRoomDialog());
        button("Сформировать PDF этого проекта",b,v->startPdf());
        button("Назад к проектам",b,v->showProjects());
    }
    private void newRoomDialog() {
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,4,24,4);
        EditText n=edit("Название комнаты","",InputType.TYPE_CLASS_TEXT);EditText len=edit("Длина комнаты (м)","5",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText wid=edit("Ширина комнаты (м)","4",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);EditText h=edit("Высота стен (м)","2.7",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText op=edit("Площадь окон и дверей (м²)","0",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        l.addView(n);l.addView(len);l.addView(wid);l.addView(h);l.addView(op);
        new AlertDialog.Builder(this).setTitle("Добавить комнату").setView(l).setNegativeButton("Отмена",null).setPositiveButton("Добавить",(d,w)->{try{JSONObject p=project();JSONArray rs=getArray(p,"rooms");JSONObject r=obj();r.put("id",nextId(rs));r.put("name",n.getText().toString().trim());r.put("length",num(len.getText().toString()));r.put("width",num(wid.getText().toString()));r.put("height",num(h.getText().toString()));r.put("openings",num(op.getText().toString()));r.put("jobs",arr());rs.put(r);p.put("rooms",rs);saveData();currentRoom=r.optInt("id");showRoom();}catch(Exception ignored){}}).show();
    }
    private JSONObject room() {return findById(getArray(project(),"rooms"),currentRoom);}
    private void showRoom() {
        JSONObject r=room();if(r==null){showProject();return;}
        LinearLayout b=root("Комната: "+r.optString("name"));
        EditText nm=edit("Название",r.optString("name"),InputType.TYPE_CLASS_TEXT);
        EditText len=edit("Длина (м)",fmt(r.optDouble("length")),InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText wid=edit("Ширина (м)",fmt(r.optDouble("width")),InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText h=edit("Высота (м)",fmt(r.optDouble("height")),InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText op=edit("Окна и двери (м²)",fmt(r.optDouble("openings")),InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        b.addView(text("Название комнаты",14));b.addView(nm);b.addView(text("Длина комнаты (м)",14));b.addView(len);b.addView(text("Ширина комнаты (м)",14));b.addView(wid);b.addView(text("Высота стен (м)",14));b.addView(h);b.addView(text("Площадь проёмов (м²)",14));b.addView(op);
        button("Сохранить размеры",b,v->{try{r.put("name",nm.getText().toString());r.put("length",num(len.getText().toString()));r.put("width",num(wid.getText().toString()));r.put("height",num(h.getText().toString()));r.put("openings",num(op.getText().toString()));saveData();showRoom();}catch(Exception ignored){}});
        b.addView(text("Площадь стен: "+fmt(roomArea(r))+" м²",19));
        b.addView(text("Работы",18));
        JSONArray jobs=getArray(r,"jobs");
        for(int i=0;i<jobs.length();i++){JSONObject j=jobs.optJSONObject(i);if(j==null)continue;final int id=j.optInt("id");
            b.addView(text(j.optString("name")+" — "+fmt(j.optDouble("qty"))+" "+j.optString("unit")+" × "+rub(j.optDouble("price"))+" = "+rub(j.optDouble("qty")*j.optDouble("price")),15));
            button("Изменить количество и цену",b,v->editJob(id));
            button("Удалить работу",b,v->{removeById(getArray(r,"jobs"),id);saveData();showRoom();});
        }
        button("+ Добавить работу из прайса",b,v->choosePriceForRoom());
        button("Назад к проекту",b,v->showProject());
    }
    private void choosePriceForRoom() {
        JSONArray ps=getArray(data,"prices");if(ps.length()==0){toast("Сначала добавь работы в прайс");return;}
        String[] labels=new String[ps.length()];for(int i=0;i<ps.length();i++){JSONObject p=ps.optJSONObject(i);labels[i]=p.optString("name")+" — "+fmt(p.optDouble("price"))+" ₽/"+p.optString("unit");}
        new AlertDialog.Builder(this).setTitle("Выбери работу").setItems(labels,(d,which)->{JSONObject p=ps.optJSONObject(which);addJobFromPrice(p);}).show();
    }
    private void addJobFromPrice(JSONObject p) {
        if(p==null)return;JSONObject r=room();if(r==null)return;
        try{JSONArray js=getArray(r,"jobs");JSONObject j=obj();j.put("id",nextId(js));j.put("name",p.optString("name"));j.put("unit",p.optString("unit"));j.put("price",p.optDouble("price"));j.put("qty",p.optString("unit").equals("м²")?roomArea(r):1);js.put(j);r.put("jobs",js);saveData();showRoom();}catch(Exception ignored){}
    }
    private void editJob(int id) {
        JSONObject j=findById(getArray(room(),"jobs"),id);if(j==null)return;
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,4,24,4);
        EditText q=edit("Количество ("+j.optString("unit")+")",fmt(j.optDouble("qty")),InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText p=edit("Цена за единицу (₽)",fmt(j.optDouble("price")),InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        l.addView(q);l.addView(p);
        new AlertDialog.Builder(this).setTitle(j.optString("name")).setView(l).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{try{j.put("qty",num(q.getText().toString()));j.put("price",num(p.getText().toString()));saveData();showRoom();}catch(Exception ignored){}}).show();
    }
    private void chooseProjectForPdf() {
        JSONArray ps=getArray(data,"projects");String[] names=new String[ps.length()];for(int i=0;i<ps.length();i++)names[i]=ps.optJSONObject(i).optString("name");
        new AlertDialog.Builder(this).setTitle("Какой проект экспортировать?").setItems(names,(d,w)->{currentProject=ps.optJSONObject(w).optInt("id");startPdf();}).show();
    }
    private double roomArea(JSONObject r) {
        return Math.max(0,2*(r.optDouble("length")+r.optDouble("width"))*r.optDouble("height")-r.optDouble("openings"));
    }
    private double roomTotal(JSONObject r) {
        double total=0;JSONArray js=getArray(r,"jobs");for(int i=0;i<js.length();i++){JSONObject j=js.optJSONObject(i);if(j!=null)total+=j.optDouble("qty")*j.optDouble("price");}return total;
    }
    private double projectTotal(JSONObject p) {
        double total=0;JSONArray rs=getArray(p,"rooms");for(int i=0;i<rs.length();i++)total+=roomTotal(rs.optJSONObject(i));return total;
    }
    private void removeById(JSONArray a,int id) {
        JSONArray out=arr();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optInt("id")!=id)out.put(x);}
        try { if(a==getArray(data,"prices"))data.put("prices",out);else if(a==getArray(project(),"rooms"))project().put("rooms",out);else if(a==getArray(room(),"jobs"))room().put("jobs",out); }catch(Exception ignored){}
    }
    private void startPdf() {
        try { pendingPdf=makePdf(project());Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,safeName(project().optString("name","Smeta"))+".pdf");startActivityForResult(i,CREATE_PDF); }
        catch(Exception e){toast("Не удалось подготовить PDF");}
    }
    private String safeName(String s){return s.replaceAll("[^A-Za-zА-Яа-я0-9 _-]","").replace(' ','_');}
    private byte[] makePdf(JSONObject p) throws Exception {
        PdfDocument doc=new PdfDocument();int pageNo=1;int y=48;int pageW=595,pageH=842;
        PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create());Canvas c=page.getCanvas();
        Paint paint=new Paint(3);paint.setColor(0xFF111111);paint.setTextSize(11);
        paint.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        y=drawLine(c,paint,"СМЕТА НА ОТДЕЛОЧНЫЕ РАБОТЫ",y,18,true);
        y=drawLine(c,paint,"Проект: "+p.optString("name"),y,12,true);
        y=drawLine(c,paint,"Адрес: "+p.optString("address","—"),y,11,false);
        y=drawLine(c,paint,"Дата: "+new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(new Date()),y,10,false);
        y+=10; double total=0;
        JSONArray rooms=getArray(p,"rooms");
        for(int i=0;i<rooms.length();i++){
            JSONObject r=rooms.optJSONObject(i);if(r==null)continue;
            if(y>730){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(pageW,pageH,++pageNo).create());c=page.getCanvas();y=48;}
            y=drawLine(c,paint,"Комната: "+r.optString("name"),y,13,true);
            y=drawLine(c,paint,"Размеры: "+fmt(r.optDouble("length"))+" × "+fmt(r.optDouble("width"))+" м; высота: "+fmt(r.optDouble("height"))+" м",y,10,false);
            y=drawLine(c,paint,"Проёмы: "+fmt(r.optDouble("openings"))+" м²; площадь стен: "+fmt(roomArea(r))+" м²",y,10,false);
            y+=4;
            y=drawLine(c,paint,"Работа | Количество | Цена | Сумма",y,10,true);
            JSONArray jobs=getArray(r,"jobs");
            for(int j=0;j<jobs.length();j++){
                JSONObject job=jobs.optJSONObject(j);if(job==null)continue;
                if(y>755){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(pageW,pageH,++pageNo).create());c=page.getCanvas();y=48;}
                String line=job.optString("name")+" | "+fmt(job.optDouble("qty"))+" "+job.optString("unit")+" | "+rub(job.optDouble("price"))+" | "+rub(job.optDouble("qty")*job.optDouble("price"));
                y=drawLine(c,paint,line,y,9,false);
            }
            y=drawLine(c,paint,"Итого по комнате: "+rub(roomTotal(r)),y+3,10,true);y+=10;total+=roomTotal(r);
        }
        if(y>730){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(pageW,pageH,++pageNo).create());c=page.getCanvas();y=48;}
        y=drawLine(c,paint,"ОБЩИЙ ИТОГ: "+rub(total),y+8,15,true);
        y=drawLine(c,paint,"Исполнитель: "+data.optString("fio",""),y+26,10,false);
        y=drawLine(c,paint,"Телефон: "+data.optString("phone",""),y,10,false);
        doc.finishPage(page);ByteArrayOutputStream out=new ByteArrayOutputStream();doc.writeTo(out);doc.close();return out.toByteArray();
    }
    private int drawLine(Canvas c,Paint p,String s,int y,int size,boolean bold) {
        p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        // Wrap long lines to printable width.
        int max=88;
        if(s.length()>max){String first=s.substring(0,max);c.drawText(first,40,y,p);c.drawText(s.substring(max),40,y+14,p);return y+28;}
        c.drawText(s,40,y,p);return y+18;
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent result) {
        super.onActivityResult(requestCode,resultCode,result);
        if(requestCode==CREATE_PDF&&resultCode==RESULT_OK&&result!=null&&result.getData()!=null){
            try(OutputStream os=getContentResolver().openOutputStream(result.getData())){os.write(pendingPdf);toast("PDF сохранён");}
            catch(Exception e){toast("Ошибка сохранения PDF");}
        }
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
